﻿namespace StudentInfo.Models
{
    public class Student
    {
        public string StudentId { get; set; }
        public string Name { get; set;}
        public string Address { get; set;}
        public int Age { get; set;}
        public string Faculty { get; set;}
        public string Major { get; set;}

        public Student() {

        }
    }
}
